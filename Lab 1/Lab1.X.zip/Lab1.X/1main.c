#include <xc.h>

//Simple delay w/o timers because of lab order
void delay(){
    int i, j;
    for(i = 0; i < 400; i++)
        for(j = 0; j < 400; j++);
}

main(){
    int count = 0;
    TRISB = 0;          // Set all B pins to output
      
    while(1){
        LATB = count;	// Write count to output pins 
        count++;
        if(count > 15)
            count = 0;
        delay();
    }
}
